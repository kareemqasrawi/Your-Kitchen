package com.kareem.yourkitchen.provider.auth.viewModel

class LoginforUserModel {
}